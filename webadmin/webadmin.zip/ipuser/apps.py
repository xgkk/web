from django.apps import AppConfig


class IpConfig(AppConfig):
    name = 'ipuser'
